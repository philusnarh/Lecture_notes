#############################################################################
#
#    APSYNSIM: A real-time Aperture Synthesis Simulator
#
#    Copyright (C) 2014  Ivan Marti-Vidal (Nordic ARC Node, OSO, Sweden)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#############################################################################



import pylab as pl
import numpy as np
from matplotlib.widgets import Slider, Button
import tkFileDialog
from tkMessageBox import showinfo
import os
import time

__version__ = '0.2.1-r2'

class Interferometer(object):

  def __init__(self,antenna_file="",model_file=""):

    self.Hfac = np.pi/180.*15.
    self.deg2rad = np.pi/180.

    self.robust = 0.0
    self.deltaAng = 1.*self.deg2rad
    self.deltaH = 0.25*self.Hfac
    self.nH = 200
    self.gamma = 0.25  # Gamma correction to plot model.
    self.Npix = 512   # Image pixel size. Must be a power of 2

    self.lock=False

    self.readAntennas(str(antenna_file))
    self.readModels(str(model_file))
    self.GUI()



  def showError(self,message):
    showinfo('ERROR!', message)
    raise Exception(message)



  def GUI(self):

    self.Nphf = self.Npix/2
    self.robfac = 0.0
    self.figUV = pl.figure(figsize=(15,8))
    self.figUV.canvas.set_window_title('Aperture Synthesis Simulator (Onsala Space Observatory)  -  version  %s'%__version__)
    self.antPlot = self.figUV.add_subplot(231,aspect='equal')
    self.UVPlot = self.figUV.add_subplot(232,aspect='equal')
    self.beamPlot = self.figUV.add_subplot(233,aspect='equal')
    self.modelPlot = self.figUV.add_subplot(235,aspect='equal')
    self.dirtyPlot = self.figUV.add_subplot(236,aspect='equal')

    self.figUV.subplots_adjust(left=0.05,right=0.99,top=0.95,bottom=0.07,hspace=0.25)
    self.figUV.canvas.mpl_connect('pick_event', self._onPick)
    self.figUV.canvas.mpl_connect('motion_notify_event', self._onAntennaDrag)
    self.figUV.canvas.mpl_connect('button_release_event',self._onRelease)
    self.pickAnt = False

    self.fmtH = r'$\phi = $ %3.1f$^\circ$   $\delta = $ %3.1f$^\circ$' "\n" r'HA = %3.1fh / %3.1fh'
    self.fmtA = 'N = %i'
    self.fmtA2 = '  Picked Ant. #%i'
    fmtB1 = r'$\lambda = $ %4.1fmm  '%(self.wavelength*1.e6)
    self.fmtB = fmtB1 + "\n" + r'% 4.2f Jy/beam' + "\n" + r'$\Delta\alpha = $ % 4.2f / $\Delta\delta = $ % 4.2f '
    self.fmtD = r'% .2e Jy/beam' "\n" r'$\Delta\alpha = $ % 4.2f / $\Delta\delta = $ % 4.2f '
    self.fmtM = r'%.2e Jy/pixel' "\n"  r'$\Delta\alpha = $ % 4.2f / $\Delta\delta = $ % 4.2f'

    self.wax = {}
    self.widget = {}
    self.wax['lat'] = pl.axes([0.07,0.45,0.25,0.04])
    self.wax['dec'] = pl.axes([0.07,0.40,0.25,0.04])
    self.wax['H0'] = pl.axes([0.07,0.35,0.25,0.04])
    self.wax['H1'] = pl.axes([0.07,0.30,0.25,0.04])
    self.wax['wave'] = pl.axes([0.07,0.25,0.25,0.04])
    self.wax['robust'] = pl.axes([0.07,0.20,0.25,0.04])
    self.wax['add'] = pl.axes([0.07,0.11,0.12,0.07])
    self.wax['rem'] = pl.axes([0.20,0.11,0.12,0.07])
    self.wax['save'] =  pl.axes([0.07,0.05,0.08,0.05]) 
    self.wax['loadarr']=pl.axes([0.155,0.05,0.08,0.05])
    self.wax['loadmod']=pl.axes([0.24,0.05,0.08,0.05])

    self.widget['robust'] = Slider(self.wax['robust'],r'Robust',-2.,2.,valinit=0.0)
    self.widget['lat'] = Slider(self.wax['lat'],r'Lat (deg)',-90.,90.,valinit=self.lat/self.deg2rad)
    self.widget['dec'] = Slider(self.wax['dec'],r'Dec (deg)',-90.,90.,valinit=self.dec/self.deg2rad)
    self.widget['H0'] = Slider(self.wax['H0'],r'H$_{0}$ (h)',-12.,12.,valinit=self.Hcov[0]/self.Hfac)
    self.widget['H1'] = Slider(self.wax['H1'],r'H$_{1}$ (h)',-12.,12.,valinit=self.Hcov[1]/self.Hfac)
    self.widget['wave'] = Slider(self.wax['wave'],r'$\lambda$ (mm)',self.wavelength*1.e6/3.,3.*self.wavelength*1.e6,valinit=self.wavelength*1.e6)
    self.widget['add'] = Button(self.wax['add'],r'+ Antenna')
    self.widget['rem'] = Button(self.wax['rem'],r'$-$ Antenna')
    self.widget['save'] = Button(self.wax['save'],'Save array')
    self.widget['loadarr'] = Button(self.wax['loadarr'],'Load array')
    self.widget['loadmod'] = Button(self.wax['loadmod'],'Load model')

    self.widget['robust'].on_changed(self._onRobust)
    self.widget['lat'].on_changed(self._onKeyLat)
    self.widget['dec'].on_changed(self._onKeyDec)
    self.widget['H0'].on_changed(self._onKeyH0)
    self.widget['H1'].on_changed(self._onKeyH1)
    self.widget['wave'].on_changed(self._changeWavelength)
    self.widget['add'].on_clicked(self._addAntenna)
    self.widget['rem'].on_clicked(self._removeAntenna)
    self.widget['save'].on_clicked(self.saveArray)
    self.widget['loadarr'].on_clicked(self.loadArray)
    self.widget['loadmod'].on_clicked(self.loadModel)


    self._prepareBeam()
    self._prepareBaselines()
    self._setBaselines()
    self._setBeam()
    self._plotBeam()
    self._plotAntennas()
    self._prepareModel()
    self._plotModel()
    self._plotDirty()

    pl.show()


  def readAntennas(self,antenna_file):
    
    self.Hcov = [-12.0*self.Hfac,12.0*self.Hfac]
    self.Hmax = np.pi
    self.lat = 45.*self.deg2rad
    self.dec = 45.*self.deg2rad
    self.trlat = [np.sin(self.lat),np.cos(self.lat)]
    self.trdec = [np.sin(self.dec), np.cos(self.dec)]
    self.Xmax = 4.0

    if len(antenna_file)==0:
      self.Nant = 7
      self.antPos=[[0.0,0.0],[0.0,1.],[0.0,2.0],[1.,-1.],[2.0,-2.0],[-1.,-1.],[-2.0,-2.0]]
    

    if len(antenna_file)>0: 
     if not os.path.exists(antenna_file):
      self.showError("\n\nAntenna file %s does not exist!\n\n"%antenna_file)
      return False
    
     else:
      antPos=[]
      Hcov = [0,0]
      Nant = 0
      Xmax = 0.0
      fi = open(antenna_file)
      for li,l in enumerate(fi.readlines()):
        comm = l.find('#')
        if comm>=0:
          l = l[:comm]     
        it = l.split()
        if len(it)>0:
          if it[0]=='ANTENNA':   
            antPos.append(map(float,it[1:]))
            Nant += 1
            antPos[-1][0] *= 1.e-3 ; antPos[-1][1] *= 1.e-3
            Xmax = np.max(np.abs(antPos[-1]+[Xmax]))
          elif it[0]=='LATITUDE':
            lat = float(it[1])*self.deg2rad
            trlat = [np.sin(lat),np.cos(lat)]
          elif it[0]=='DECLINATION':
            dec = float(it[1])*self.deg2rad
            trdec = [np.sin(dec),np.cos(dec)]
          elif it[0]=='HOUR_ANGLE':
            Hcov[0] = float(it[1])*self.Hfac
            Hcov[1] = float(it[2])*self.Hfac
          else:
            self.showError("\n\nWRONG SYNTAX IN LINE %i:\n\n %s...\n\n"%(li+1,l[:max(10,len(l))]))


      if np.abs(lat-dec>=np.pi/2.):
         self.showError("\n\nSource is either not observable or just at the horizon!\n\n")
         return False
      if Nant<2:
         self.showError("\n\nThere should be at least 2 antennas!\n\n")
         return False



      self.Nant = Nant
      self.antPos = antPos
      self.lat = lat
      self.dec = dec
      self.trlat = trlat
      self.trdec = trdec
      self.Hcov = Hcov
      self.Xmax = Xmax


      cosW = -np.tan(self.lat)*np.tan(self.dec)
      if np.abs(cosW) < 1.0:
        Hhor = np.arccos(cosW)
      elif np.abs(self.lat-self.dec)>np.pi/2.:
        Hhor = 0
      else:
        Hhor = np.pi

      if Hhor>0.0:
        if self.Hcov[0]< -Hhor:
          self.Hcov[0] = -Hhor
        if self.Hcov[1]>  Hhor:
          self.Hcov[1] =  Hhor

      self.Hmax = Hhor
      H = np.linspace(self.Hcov[0],self.Hcov[1],self.nH)[np.newaxis,:]
      self.Xmax = Xmax*2.0
      fi.close()
   
    return True




  def readModels(self,model_file):

    self.wavelength = 1.e-6  # in km.
    self.imsize = 4. 

    if len(model_file)==0:
      self.models = [['G',0.,0.4,1.0,0.1],['D',0.,0.,2.,0.5],['P',-0.4,-0.5,0.1]]
      self.Xaxmax = self.imsize/2.
      return True

    if len(model_file)>0: 
     if not os.path.exists(model_file):
      self.showError("\n\nModel file %s does not exist!\n\n"%model_file)
      return False

     else:
      fixsize = False
      models = []
      Xmax = 0.0
      fi = open(model_file)
      for li,l in enumerate(fi.readlines()):
        comm = l.find('#')
        if comm>=0:
          l = l[:comm]     
        it = l.split()
        if len(it)>0:
          if it[0] in ['G','D','P']:   
            models.append([it[0]]+map(float,it[1:]))
            if models[-1][0] != 'P':
              models[-1][4] = np.abs(models[-1][4])
              Xmax = np.max([np.abs(models[-1][1])+models[-1][4],
                 np.abs(models[-1][2])+models[-1][4],Xmax])
          elif it[0] == 'WAVELENGTH':
            wavelength = float(it[1])*1.e-3
          elif it[0] == 'IMSIZE':
            imsize = 2.*float(it[1])
            fixsize = True
          else:
            self.showError("\n\nWRONG SYNTAX IN LINE %i:\n\n %s...\n\n"%(li+1,l[:max(10,len(l))]))

      if len(models)==0:
         self.showError("\n\nThere should be at least 1 model component!\n\n")

      self.models=models
      self.wavelength=wavelength
      self.imsize=imsize


      if not fixsize:
        self.imsize = Xmax*1.1


      self.Xaxmax = self.imsize/2.

      fi.close()



    return True





  def _changeWavelength(self,wave):

     self.wavelength = wave*1.e-6
     fmtB1 = r'$\lambda = $ %4.1fmm  '%(self.wavelength*1.e6)
     self.fmtB = fmtB1 + "\n" r'% 4.2f Jy/beam' "\n" r'$\Delta\alpha = $ % 4.2f / $\Delta\delta = $ % 4.2f '

     self._plotAntennas(redo=False)
     self._changeCoordinates(rescale=True)



  def _changeCoordinates(self,rescale=False):

    if self.lat>np.pi/2.:
      self.lat = np.pi/2.
      return
    elif self.lat<-np.pi/2.:
      self.lat = -np.pi/2.
      return

    if self.dec>np.pi/2.:
      self.dec = np.pi/2.
      return
    elif self.dec<-np.pi/2.:
      self.dec = -np.pi/2.
      return

    self.trlat = [np.sin(self.lat),np.cos(self.lat)]
    self.trdec = [np.sin(self.dec), np.cos(self.dec)]


    cosW = -np.tan(self.lat)*np.tan(self.dec)
    if np.abs(cosW) < 1.0:
      Hhor = np.arccos(cosW)
    elif np.abs(self.lat-self.dec)>np.pi/2.:
      Hhor = 0
    else:
      Hhor = np.pi

    self.Hmax = Hhor

    if self.Hmax>0.0:
      if self.Hcov[0]< -self.Hmax:
        self.Hcov[0] = -self.Hmax
        self.lock=True
        self.widget['H0'].set_val(self.Hcov[0]/self.Hfac)
        self.lock=False
      if self.Hcov[1]>  self.Hmax:
        self.Hcov[1] =  self.Hmax
        self.lock=True
        self.widget['H1'].set_val(self.Hcov[1]/self.Hfac)
        self.lock=False


    newtext = self.fmtH%(self.lat/self.deg2rad,self.dec/self.deg2rad,self.Hcov[0]/self.Hfac,self.Hcov[1]/self.Hfac)
    self.latText.set_text(newtext) 
    H = np.linspace(self.Hcov[0],self.Hcov[1],self.nH)[np.newaxis,:]
    self.H = [np.sin(H),np.cos(H)] 
    self._setBaselines()
    self._setBeam()
    self._plotBeam(redo=False)
    self._plotAntennas(redo=False,rescale=True)
    self._plotDirty(redo=False)

    pl.draw()



  def _prepareBeam(self):
    
    self.beam = np.zeros((self.Npix,self.Npix),dtype=np.float32)
    self.totsampling = np.zeros((self.Npix,self.Npix),dtype=np.float32)
    self.dirtymap = np.zeros((self.Npix,self.Npix),dtype=np.float32)
    self.totsamplingU = np.zeros((self.Npix,self.Npix),dtype=np.float32)
    self.robustsamp = np.zeros((self.Npix,self.Npix),dtype=np.float32)


  def _prepareBaselines(self):

    self.Nbas = self.Nant*(self.Nant-1)/2
    NBmax = self.Nbas
    self.B = np.zeros((NBmax,self.nH),dtype=np.float32)
    self.basnum = np.zeros((self.Nant,self.Nant-1),dtype=np.int8)
    self.refant = np.zeros((self.Nant,self.Nant-1),dtype=np.int8)
    self.basidx = np.zeros((self.Nant,self.Nant),dtype=np.int8)
    self.antnum = np.zeros((NBmax,2),dtype=np.int8)

    H = np.linspace(self.Hcov[0],self.Hcov[1],self.nH)[np.newaxis,:]
    self.H = [np.sin(H),np.cos(H)]

    bi = 0
    nii = [0 for n in range(self.Nant)]
    for n1 in range(self.Nant-1):
      for n2 in range(n1+1,self.Nant):
        self.basnum[n1,nii[n1]] = bi
        self.basnum[n2,nii[n2]] = bi
        self.basidx[n1,n2] = bi
        self.antnum[bi] = [n1,n2]
        self.refant[n1,nii[n1]] = 0
        self.refant[n2,nii[n2]] = 1
        nii[n1] += 1; nii[n2] += 1
        bi += 1

    self.u = np.zeros((NBmax,self.nH))
    self.v = np.zeros((NBmax,self.nH))

    self.sampling = np.zeros((self.Nant,self.Npix,self.Npix),dtype=np.float32)



  def _setBaselines(self,antidx=-1):

   if antidx==-1:
     bas2change = range(self.Nbas)
   else:
     bas2change = self.basnum[antidx].flatten()

   for currBas in bas2change:
     n1,n2 = self.antnum[currBas]
     self.B[currBas,0] = -(self.antPos[n2][1]-self.antPos[n1][1])*self.trlat[0]/self.wavelength
     self.B[currBas,1] = (self.antPos[n2][0]-self.antPos[n1][0])/self.wavelength
     self.B[currBas,2] = (self.antPos[n2][1]-self.antPos[n1][1])*self.trlat[1]/self.wavelength
     self.u[currBas,:] = self.B[currBas,0]*self.H[0] + self.B[currBas,1]*self.H[1]
     self.v[currBas,:] = -self.B[currBas,0]*self.trdec[0]*self.H[1]+self.B[currBas,1]*self.trdec[0]*self.H[0]+self.trdec[1]*self.B[currBas,2]




  def _gridUV(self,antidx=-1):

   if antidx==-1:
     bas2change = range(self.Nbas)
     dummy = np.zeros(self.Npix*self.Npix,dtype=np.int8)
     self.pixU = [dummy for nb in bas2change]
     self.pixV = [dummy for nb in bas2change]
     self.totsampling[:] = 0.0
   else:
     bas2change = self.basnum[antidx].flatten()

  # Nphf = int(self.Npix/2)
   self.UVpixsize = 2./(self.imsize*np.pi/180./3600.)


   for nb in bas2change:
     pixU = np.rint(self.u[nb]/self.UVpixsize).flatten().astype(np.int32)
     pixV = np.rint(self.v[nb]/self.UVpixsize).flatten().astype(np.int32)
     goodpix = np.logical_and(np.abs(pixU)<self.Nphf,np.abs(pixV)<self.Nphf)
     if not antidx==-1:
      for pi in range(len(self.pixU[nb])):
       self.totsampling[self.pixV[nb][pi]+self.Nphf,-self.pixU[nb][pi]+self.Nphf] -= 1.0
       self.totsampling[-self.pixV[nb][pi]+self.Nphf,self.pixU[nb][pi]+self.Nphf] -= 1.0

     self.pixU[nb] = np.copy(pixU[goodpix])
     self.pixV[nb] = np.copy(pixV[goodpix])
     for pi in range(len(self.pixU[nb])):
       self.totsampling[self.pixV[nb][pi]+self.Nphf,-self.pixU[nb][pi]+self.Nphf] += 1.0
       self.totsampling[-self.pixV[nb][pi]+self.Nphf,self.pixU[nb][pi]+self.Nphf] += 1.0

   self.totsamplingU[:] = 0.0
   self.totsamplingU[self.totsampling>0.0] = 1.0
   self.robfac = (5.*10.**(-self.robust))**2.*(2.*self.Nbas*self.nH)/np.sum(self.totsampling**2.)


  def _setBeam(self,antidx=-1):

  # print 'A:',self.robfac
   self._gridUV(antidx=antidx) 
  # print 'B:',self.robfac

   self.robustsamp[:] = self.totsampling/(1.+self.robfac*self.totsampling)


   self.beam[:] = np.fft.ifftshift(np.fft.ifft2(np.fft.fftshift(self.robustsamp))).real 
  # Nphf = int(self.Npix/2)
   self.beamScale = np.max(self.beam[self.Nphf:self.Nphf+1,self.Nphf:self.Nphf+1])
   self.beam[:] /= self.beamScale

  # print 'C:',np.std(self.beam)


  def _prepareModel(self):

    pixsize = float(self.imsize)/self.Npix
    xx = np.linspace(-self.imsize/2.,self.imsize/2.,self.Npix)
    yy = np.ones(self.Npix,dtype=np.float32)
    distmat = np.zeros((self.Npix,self.Npix),dtype=np.float32)
    self.modelim = np.zeros((self.Npix,self.Npix),dtype=np.float32)
   # Nphf = int(self.Npix/2)
    for model in self.models:
      xsh = -model[1]
      ysh = -model[2]
      xpix = np.rint(xsh/pixsize).astype(np.int32)
      ypix = np.rint(ysh/pixsize).astype(np.int32)
      centy = np.roll(xx,ypix)
      centx = np.roll(xx,xpix)
      distmat[:] = np.outer(centy**2.,yy) + np.outer(yy,centx**2.)
      if model[0]=='D':
        mask = np.logical_or(distmat<=model[4]**2.,distmat==np.min(distmat))
        self.modelim[mask] += float(model[3])/np.sum(mask)
      elif model[0]=='G':
        gauss = np.exp(-distmat/(2.*model[4]**2.))
        self.modelim[:] += float(model[3])*gauss/np.sum(gauss)
      elif model[0]=='P':
        if np.abs(xpix+self.Nphf)<self.Npix and np.abs(ypix+self.Nphf)<self.Npix:
          yint = ypix+self.Nphf
          xint = xpix+self.Nphf
       #   print ypix+Nphf, xpix+Nphf
          self.modelim[yint,xint] += float(model[3])

    self.modelfft = np.fft.fft2(np.fft.fftshift(self.modelim))


  def _plotModel(self,redo=True):
    
    Np4 = self.Npix/4

    if redo:
      self.modelPlotPlot = self.modelPlot.imshow(np.power(self.modelim[Np4:self.Npix-Np4,Np4:self.Npix-Np4],self.gamma),picker=True,interpolation='nearest',vmin=0.0,vmax=np.max(self.modelim)**self.gamma)
      modflux = self.modelim[self.Nphf,self.Nphf]
      self.modelText = self.modelPlot.text(0.05,0.87,self.fmtM%(modflux,0.0,0.0),
         transform=self.modelPlot.transAxes,bbox=dict(facecolor='white', 
         alpha=0.7))
      pl.setp(self.modelPlotPlot, extent=(self.Xaxmax/2.,-self.Xaxmax/2.,-self.Xaxmax/2.,self.Xaxmax/2.))
      self.modelPlot.set_ylabel('Dec offset (as)')
      self.modelPlot.set_xlabel('RA offset (as)')
      self.modelPlot.set_title('MODEL IMAGE')
    else:
      self.modelPlotPlot.set_data(np.power(self.modelim[Np4:self.Npix-Np4,Np4:self.Npix-Np4],self.gamma))
      pl.setp(self.modelPlotPlot, extent=(self.Xaxmax/2.,-self.Xaxmax/2.,-self.Xaxmax/2.,self.Xaxmax/2.))




  def _plotDirty(self,redo=True):
    Np4 = self.Npix/4

    self.dirtymap[:] = np.fft.fftshift(np.fft.ifft2(self.modelfft*np.fft.ifftshift(self.robustsamp))).real/self.beamScale
    extr = [np.min(self.dirtymap),np.max(self.dirtymap)]
   # Nphf = int(self.Npix/2)
    if redo:
      self.dirtyPlotPlot = self.dirtyPlot.imshow(self.dirtymap[Np4:self.Npix-Np4,Np4:self.Npix-Np4],interpolation='nearest',picker=True)
      modflux = self.dirtymap[self.Nphf,self.Nphf]
      self.dirtyText = self.dirtyPlot.text(0.05,0.87,self.fmtD%(modflux,0.0,0.0),
         transform=self.dirtyPlot.transAxes,bbox=dict(facecolor='white', 
         alpha=0.7))
      pl.setp(self.dirtyPlotPlot, extent=(self.Xaxmax/2.,-self.Xaxmax/2.,-self.Xaxmax/2.,self.Xaxmax/2.))
      self.dirtyPlot.set_ylabel('Dec offset (as)')
      self.dirtyPlot.set_xlabel('RA offset (as)')
      self.dirtyPlot.set_title('DIRTY IMAGE')
    else:
      self.dirtyPlotPlot.set_data(self.dirtymap[Np4:self.Npix-Np4,Np4:self.Npix-Np4])
      self.dirtyPlotPlot.norm.vmin = extr[0]
      self.dirtyPlotPlot.norm.vmax = extr[1]
      pl.setp(self.dirtyPlotPlot, extent=(self.Xaxmax/2.,-self.Xaxmax/2.,-self.Xaxmax/2.,self.Xaxmax/2.))






  def _plotAntennas(self,redo=True,rescale=False):

   lfac = 1.e6

   if redo:
    toplot = np.array(self.antPos[:self.Nant])
    self.antPlotPlot = self.antPlot.plot(toplot[:,0],toplot[:,1],'og', picker=5)[0]
    self.antPlot.set_xlim((-self.Xmax,self.Xmax))
    self.antPlot.set_ylim((-self.Xmax,self.Xmax))
    self.antPlot.set_xlabel('E-W offset (km)')
    self.antPlot.set_ylabel('N-S offset (km)')
    self.antPlot.set_title('ARRAY CONFIGURATION')
    self.antText = self.antPlot.text(0.05,0.92,self.fmtA%self.Nant,transform=self.antPlot.transAxes)

    self.UVPlotPlot = []
    toplotu = self.u.flatten()/lfac ;  toplotv = self.v.flatten()/lfac ; 
    self.UVPlotPlot.append(self.UVPlot.plot(toplotu, toplotv,'.b',markersize=1)[0])
    self.UVPlotPlot.append(self.UVPlot.plot(-toplotu,-toplotv,'.r',markersize=1)[0])
    self.UVPlot.set_xlim((-2.*self.Xmax/self.wavelength/lfac,2.*self.Xmax/self.wavelength/lfac))
    self.UVPlot.set_ylim((-2.*self.Xmax/self.wavelength/lfac,2.*self.Xmax/self.wavelength/lfac))
    self.latText = self.UVPlot.text(0.05,0.87,self.fmtH%(self.lat/self.deg2rad,self.dec/self.deg2rad,self.Hcov[0]/self.Hfac,self.Hcov[1]/self.Hfac),transform=self.UVPlot.transAxes)
    self.UVPlot.set_xlabel(r'U (M$\lambda$)')
    self.UVPlot.set_ylabel(r'V (M$\lambda$)') 
    self.UVPlot.set_title('UV COVERAGE')

   else:
    toplot = np.array(self.antPos[:self.Nant])
    self.antPlotPlot.set_data(toplot[:,0],toplot[:,1])
    toplotu = self.u.flatten()/lfac ;  toplotv = self.v.flatten()/lfac ; 
    if rescale:
      self.antPlot.set_xlim((-self.Xmax,self.Xmax))
      self.antPlot.set_ylim((-self.Xmax,self.Xmax))
      self.UVPlot.set_xlim((-2.*self.Xmax/self.wavelength/lfac,2.*self.Xmax/self.wavelength/lfac))
      self.UVPlot.set_ylim((-2.*self.Xmax/self.wavelength/lfac,2.*self.Xmax/self.wavelength/lfac))

    self.UVPlotPlot[0].set_data(toplotu,toplotv)
    self.UVPlotPlot[1].set_data(-toplotu,-toplotv)




  def _plotBeam(self,redo=True):

    Np4 = self.Npix/4
    if redo:
      self.beamPlotPlot = self.beamPlot.imshow(self.beam[Np4:self.Npix-Np4,Np4:self.Npix-Np4],picker=True,interpolation='nearest')
      self.beamText = self.beamPlot.text(0.05,0.82,self.fmtB%(1.0,0.0,0.0),
           transform=self.beamPlot.transAxes,bbox=dict(facecolor='white', alpha=0.7))
      self.beamPlot.set_ylabel('Dec offset (as)')
      self.beamPlot.set_xlabel('RA offset (as)')
      pl.setp(self.beamPlotPlot, extent=(self.Xaxmax/2.,-self.Xaxmax/2.,-self.Xaxmax/2.,self.Xaxmax/2.))
      self.beamPlot.set_title('DIRTY BEAM')
      pl.draw()
    else:
      self.beamPlotPlot.set_data(self.beam[Np4:self.Npix-Np4,Np4:self.Npix-Np4])
      self.beamText.set_text(self.fmtB%(1.0,0.0,0.0))
      pl.setp(self.beamPlotPlot, extent=(self.Xaxmax/2.,-self.Xaxmax/2.,-self.Xaxmax/2.,self.Xaxmax/2.))


    self.nptot = np.sum(self.totsamplingU[:])
    self.beamPlotPlot.norm.vmin = np.min(self.beam)
    self.beamPlotPlot.norm.vmax = 1.0

    if np.sum(self.totsamplingU[self.Nphf-8:self.Nphf+8,self.Nphf-8:self.Nphf+8])==self.nptot:
      warn = 'WARNING!\nToo short baselines for such a small image\nPLEASE, INCREASE THE IMAGE SIZE!\nAND/OR DECREASE THE WAVELENGTH'
      self.beamText.set_text(warn)




  def _onPick(self,event):

   if event.mouseevent.inaxes == self.beamPlot:

     RA = event.mouseevent.xdata
     Dec = event.mouseevent.ydata
     yi = np.floor((self.Xaxmax-RA)/(2.*self.Xaxmax)*self.Npix)
     xi = np.floor((self.Xaxmax-Dec)/(2.*self.Xaxmax)*self.Npix)
     Flux = self.beam[xi,yi]
     self.beamText.set_text(self.fmtB%(Flux,RA,Dec))
     pl.draw()

   if event.mouseevent.inaxes == self.dirtyPlot:

     RA = event.mouseevent.xdata
     Dec = event.mouseevent.ydata
     yi = np.floor((self.Xaxmax-RA)/(2.*self.Xaxmax)*self.Npix)
     xi = np.floor((self.Xaxmax-Dec)/(2.*self.Xaxmax)*self.Npix)
     Flux = self.dirtymap[xi,yi]
     self.dirtyText.set_text(self.fmtD%(Flux,RA,Dec))
     pl.draw()

   if event.mouseevent.inaxes == self.modelPlot:

     RA = event.mouseevent.xdata
     Dec = event.mouseevent.ydata
     yi = np.floor((self.Xaxmax-RA)/(2.*self.Xaxmax)*self.Npix)
     xi = np.floor((self.Xaxmax-Dec)/(2.*self.Xaxmax)*self.Npix)
     Flux = self.modelim[xi,yi]
     self.modelText.set_text(self.fmtM%(Flux,RA,Dec))
     pl.draw()

   elif event.mouseevent.inaxes == self.antPlot:

    if event.mouseevent.button==1 and not self.pickAnt:
     self.antidx = event.ind
     if len(self.antidx) > 1:
       self.antidx = self.antidx[-1]
     self.pickAnt = True
     self.antText.set_text(self.fmtA%self.Nant + self.fmtA2%self.antidx)
     pl.draw()

  def _onAntennaDrag(self,event):   
     if self.pickAnt:
       self.antPos[self.antidx] = [event.xdata,event.ydata]
       self._setBaselines(antidx=self.antidx)
       self._plotAntennas(redo=False)
       self._setBeam(antidx=self.antidx)
       self._plotBeam(redo=False)
       self._plotDirty(redo=False)
       pl.draw()


  def _onRelease(self,event):
     if self.pickAnt:
       self.pickAnt = False
       self.antText.set_text(self.fmtA%self.Nant)
       pl.draw()


  def _onRobust(self,newrob):
    self.robust = newrob
    self._changeCoordinates()


  def _onKeyLat(self,newlat):
   newlat *= self.deg2rad
   if not self.lock:
    self.lock = True
    if newlat != self.lat: 
     if np.abs(newlat-self.dec)<np.pi/2.:
      self.lat = newlat
      self._changeCoordinates()
     else:
      self.widget['lat'].set_val(self.lat/self.deg2rad)
    self.lock = False



  def _onKeyDec(self,newdec):
   newdec *= self.deg2rad
   if not self.lock:
    self.lock=True
    if newdec != self.dec: 
     if np.abs(newdec-self.lat)<np.pi/2.:
      self.dec = newdec
      self._changeCoordinates()
     else:
      self.widget['dec'].set_val(self.dec/self.deg2rad)
    self.lock = False



  def _onKeyH0(self,newH0):
   newH0 *= self.Hfac
   if not self.lock:
    self.lock = True
    if np.abs(newH0) < self.Hmax:
      self.Hcov[0] = newH0
    else:
      self.Hcov[0] = -self.Hmax
      self.widget['H0'].set_val(self.Hcov[0]/self.Hfac) 
    if self.Hcov[1]<self.Hcov[0]:
      self.Hcov[1] = self.Hcov[0]
      self.widget['H1'].set_val(self.Hcov[1]/self.Hfac) 
    self._changeCoordinates()
    self.lock=False



  def _onKeyH1(self,newH1):
   newH1 *= self.Hfac
   if not self.lock:
    self.lock = True
    if np.abs(newH1) < self.Hmax:
      self.Hcov[1] = newH1
    else:
      self.Hcov[1] = self.Hmax
      self.widget['H1'].set_val(self.Hcov[1]/self.Hfac) 
    if self.Hcov[0]>self.Hcov[1]:
      self.Hcov[0] = self.Hcov[1]
      self.widget['H0'].set_val(self.Hcov[0]/self.Hfac) 
    self._changeCoordinates()
    self.lock=False


  def _addAntenna(self,antenna):

    if self.Nant >= len(self.antPos):
      self.antPos.append([0.,0.])
      self.Nant += 1
    else:
      self.Nant += 1
    newtext = self.fmtA%self.Nant 
    self.antText.set_text(newtext)
    self._prepareBaselines()
    self._changeCoordinates()


  def _removeAntenna(self,antenna):
    if self.Nant > 2:
        self.Nant -= 1
    newtext = self.fmtA%self.Nant 
    self.antText.set_text(newtext)
    self._prepareBaselines()
    self._changeCoordinates()



  def saveArray(self,array):

    fname = tkFileDialog.asksaveasfilename(defaultextension='.array',title='Save current array...')
    iff = open(fname,'w')

    print >> iff,'LATITUDE % 3.1f'%(self.lat/self.deg2rad)
    print >> iff,'DECLINATION % 3.1f'%(self.dec/self.deg2rad)
    toprint = tuple([l/self.Hfac for l in self.Hcov])
    print >> iff,'HOUR_ANGLE % 3.1f  % 3.1f'%toprint
    for ant in self.antPos:
      toprint = tuple([p*1.e3 for p in ant])
      print >> iff,'ANTENNA  % .3e   % .3e'%toprint

    self.antText.set_text('SAVED: %s'%os.path.basename(fname))
    pl.draw()
    time.sleep(3)
    self.antText.set_text(self.fmtA%self.Nant) 
    pl.draw()
    iff.close()

          
    return


  def loadArray(self,array):

    antenna_file = tkFileDialog.askopenfilename(title='Load array...')
    self.lock=False

    if len(antenna_file)>0:
      goodread = self.readAntennas(str(antenna_file))

      if goodread:
        self._prepareBaselines()
        self._changeCoordinates() 
        newtext = self.fmtA%self.Nant 
        self.antText.set_text(newtext)
        self.widget['lat'].set_val(self.lat/self.deg2rad)
        self.widget['dec'].set_val(self.dec/self.deg2rad)
        self.widget['H0'].set_val(self.Hcov[0]/self.Hfac)
        self.widget['H1'].set_val(self.Hcov[1]/self.Hfac)
        self.widget['wave'].set_val(self.wavelength*1.e6)
        self._plotAntennas(redo=False,rescale=True)
        pl.draw()

    return


  def loadModel(self,model):

    model_file = tkFileDialog.askopenfilename(title='Load model...')
    self.lock=False

    if len(model_file)>0:
      goodread = self.readModels(str(model_file))

      if goodread:
        self._prepareModel()
        self._plotModel(redo=False)
        self.widget['wave'].set_val(self.wavelength*1.e6)
        self._changeCoordinates()

        self.wax['wave'].cla()
        self.widget['wave'] = Slider(self.wax['wave'],r'$\lambda$ (mm)',self.wavelength*1.e6/3.,3.*self.wavelength*1.e6,valinit=self.wavelength*1.e6)
        self.widget['wave'].on_changed(self._changeWavelength)
        pl.draw()


    return





if __name__ == "__main__":
  myint = Interferometer()

# Just some test code. 
# Do your tests here (and set it to True! :D):
  if False:
   fig = pl.figure(figsize=(6,6))
   if False:
    sub = fig.add_subplot(111)
    fig.subplots_adjust(bottom=0.01,left=0.01,right=0.99,top=0.95)
    pl1 = pl.imshow(myint.beam[256-15:256+16,256-15:256+16],interpolation='nearest')
    pl.setp(sub.get_xticklabels(),visible=False)
    pl.setp(sub.get_yticklabels(),visible=False)
    pl.title('BEAM (NATURAL)')
    pl.savefig('beam-natural.plot.png')
    pl.clf()
   if False:
    sub = fig.add_subplot(111)
    fig.subplots_adjust(bottom=0.01,left=0.01,right=0.99,top=0.95)
    pl1 = pl.imshow(myint.dirtymap)
    pl.setp(sub.get_xticklabels(),visible=False)
    pl.setp(sub.get_yticklabels(),visible=False)
    pl.title('DIRTY IMAGE')
    pl.savefig('dirtymap.plot.png')
    pl.clf()
   if False:
    sub = fig.add_subplot(111)
    fig.subplots_adjust(bottom=0.01,left=0.01,right=0.99,top=0.95)
    pl1 = pl.imshow(myint.modelim)
    pl.setp(sub.get_xticklabels(),visible=False)
    pl.setp(sub.get_yticklabels(),visible=False)
    pl.title('TRUE IMAGE')
    pl.savefig('model.plot.png')
    pl.clf()
   toplot = np.power(np.fft.ifftshift(np.abs(myint.modelfft)),0.25)
   if False:
    sub = fig.add_subplot(111)
    fig.subplots_adjust(bottom=0.01,left=0.01,right=0.99,top=0.95)
    pl1 = pl.imshow(toplot)
    pl.setp(sub.get_xticklabels(),visible=False)
    pl.setp(sub.get_yticklabels(),visible=False)
    pl.title('UV PLANE')
    pl.savefig('uvplane.plot.png')
    pl.clf()
   if True:
    import matplotlib.cm as cm
    sub = fig.add_subplot(111)
    fig.subplots_adjust(bottom=0.01,left=0.01,right=0.99,top=0.95)
    pl1 = pl.imshow(myint.totsampling>0.0,cmap = cm.Greys_r,
                    interpolation='nearest')
    pl.setp(sub.get_xticklabels(),visible=False)
    pl.setp(sub.get_yticklabels(),visible=False)
    pl.title('UV SAMPLING')
    pl.savefig('uvsampling.plot.png')
    pl1 = pl.imshow(toplot*(myint.totsampling>0.0),interpolation='nearest',vmax=np.max(toplot),vmin=np.min(toplot))
    pl.setp(sub.get_xticklabels(),visible=False)
    pl.setp(sub.get_yticklabels(),visible=False)
    pl.title('UV DATA')
    pl.savefig('uvdata.plot.png')

    pl.clf()
    sub = fig.add_subplot(111)
    fig.subplots_adjust(bottom=0.01,left=0.01,right=0.99,top=0.95)
    toplot = np.fft.fftshift(np.fft.ifft2((np.fft.ifftshift(myint.totsampling>0.01).astype(np.float32))).real)
    pl1 = pl.imshow(toplot[256-60:256+60,256-60:256+60],interpolation='nearest')
    pl.setp(sub.get_xticklabels(),visible=False)
    pl.setp(sub.get_yticklabels(),visible=False)
    pl.title('BEAM (UNIFORM)')
    pl.savefig('beam-uniform.plot.png')
    pl.clf()

   if False:
    sub = fig.add_subplot(111)
    fig.subplots_adjust(bottom=0.01,left=0.01,right=0.99,top=0.95)
    toinvert = np.logical_not(myint.totsampling>0.01)
    pm = 0.2
    dist = np.linspace(-128,128,256); odist = np.ones(256)
    dd = np.exp(-(np.outer(dist,odist)**2.+np.outer(odist,dist)**2.)/(2.*pm**2.))
    toinvert[:]*=dd

    toplot = np.abs(np.fft.fftshift(np.fft.fft2((np.fft.fftshift(toinvert).astype(np.float32)))))
    toplot += np.min(toplot)
    toplot=np.power(toplot,0.45)
    pl1 = pl.imshow(toplot,vmax=np.max(toplot),vmin=-np.max(toplot),interpolation='nearest')

    pl.setp(sub.get_xticklabels(),visible=False)
    pl.setp(sub.get_yticklabels(),visible=False)
    pl.title('PECULIAR SOURCE')
    pl.savefig('invisible.png')

    pl1.set_data(np.zeros((256,256)))
    pl.title('PECULIAR DIRTY IMAGE')
    pl.savefig('zeros.png')

